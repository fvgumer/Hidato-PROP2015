package CLUSTER.VISTAS;
import CLUSTER.VISTAS.CONTROLADORES.CtrlVista;

public class Main {
	
	public static void main(String[] args){
		CtrlVista cv = new CtrlVista();
		cv.run();
	}
}
