package JOEL;

/**
 * Test que prueba el metodo de reset y eliminado de todas las carpetas de los objetos
 * @author Joel Codina
 */
public class TestGestionHidato {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CtrlGestionEstadisticas gestor = new CtrlGestionEstadisticas();
		gestor.clean_all();
}
}

